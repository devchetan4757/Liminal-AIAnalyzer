import ChatWindow from './components/ChatWindow'
import ProtectedRoute from './components/ProtectedRoute'

export default function App() {
  return (
    <ProtectedRoute>
      <ChatWindow />
    </ProtectedRoute>
  )
}
